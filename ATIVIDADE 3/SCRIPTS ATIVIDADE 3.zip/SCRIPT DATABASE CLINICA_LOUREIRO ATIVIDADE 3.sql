CREATE DATABASE CLINICA_LOUREIRO;

USE CLINICA_LOUREIRO;

CREATE TABLE especialidade 
(
   id_especialidades int not null auto_increment unique,
   pediatria bit,
   clinica_geral bit,
   gastroenterologia bit,
   dermatologia bit,
   primary key (id_especialidades)
);

CREATE TABLE medicos
(
    id_medicos int auto_increment unique,
    id_especialidades int,
    nome varchar(60),
    crm varchar (10),
    data_nascimento date,
    endereco varchar(150),
    telefone varchar(14),
    email varchar(100),
    primary key (id_medicos),
    foreign key (id_especialidades) references especialidade (id_especialidades)
);

CREATE TABLE medicos_especialidade
(
   id_medicos_especialidade int not null auto_increment unique,
   id_medicos int,
   id_especialidades int,
   primary key (id_medicos_especialidade),
   foreign key (id_medicos) references medicos(id_medicos),
   foreign key (id_especialidades) references especialidade (id_especialidades)
);

CREATE TABLE convenio 
(
   id_convenio int not null auto_increment unique,
   nome varchar(45),
   cnpj varchar(19),
   primary key (id_convenio)
);

CREATE TABLE receituario
(
   id_receituario int not null auto_increment unique,
   instrucoes longtext,
   medicamento_1 varchar(45),
   medicamento_2 varchar(45),
   medicamento_3 varchar(45),
   quant_medicamento_1 int,
   quant_medicamento_2 int,
   quant_medicamento_3 int,
   data_consulta datetime,
   primary key (id_receituario)
);

CREATE TABLE pacientes
(
    id_pacientes int not null auto_increment unique,
    id_convenio int null,
    tempo_carencia year,
    nome varchar(60) NOT NULL,
    cpf varchar(14) not null,
    rg varchar(12) not null,
    data_nascimento date not null,
    cep varchar(9) not null,
    telefone varchar(14) not null,
    email varchar(100) not null,
    primary key (id_pacientes),
    foreign key (id_convenio) references convenio(id_convenio)
    ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE consultas
(
   id_consulta int auto_increment unique,
   id_medicos int,
   id_pacientes int,
   id_receituario int,
   id_conveni int null,
   id_medicos_especialidade int,
   valor int,
   data_realizada datetime,
   primary key (id_consulta),
   foreign key (id_medicos) references medicos (id_medicos),
   foreign key (id_pacientes) references pacientes (id_pacientes),
   foreign key (id_receituario) references receituario (id_receituario),
   foreign key (id_conveni) references convenio (id_convenio)
   ON DELETE SET NULL ON UPDATE CASCADE,
   foreign key (id_medicos_especialidade) references medicos_especialidade (id_medicos_especialidade)
);

CREATE TABLE enfermeiros
(
    id_enfermeiro int not null auto_increment unique,
    nome varchar(60),
    cre varchar (12),
    data_nascimento date,
    primary key (id_enfermeiro)
);

CREATE TABLE tipos_quarto
(
    id_tipodequarto int not null auto_increment unique,
    apartamento bit,
    valor_apartamento decimal,
    quarto_duplo bit,
    valor_quartoduplo decimal,
    enfermaria bit,
    valor_enfermaria decimal,
    primary key (id_tipodequarto)
);

CREATE TABLE quarto
(
    id_quarto int not null auto_increment unique,
    id_tipodequarto int,    
    numero_quarto int,
    primary key (id_quarto),
    foreign key (id_tipodequarto) references tipos_quarto (id_tipodequarto)
);

CREATE TABLE internacao
(
    id_internacao int not null auto_increment unique,
    id_quarto int,
    data_entrada datetime not null,
    data_prevista datetime not null,
    data_saida datetime not null,
    procedimentos longtext,
    primary key (id_internacao),
    foreign key (id_quarto) references quarto (id_quarto)
);

CREATE TABLE internacao_paciente_medico
(
    id_internacao_paciente_medico int not null auto_increment unique,
    id_internacao int,
    id_medicos int,
    id_pacientes int,
    id_enfermeiro int,
    id_enfermeiro_2 int,
    primary key (id_internacao_paciente_medico),
    foreign key (id_internacao) references internacao (id_internacao),
    foreign key (id_medicos) references medicos (id_medicos),
    foreign key (id_pacientes) references pacientes (id_pacientes),
    foreign key (id_enfermeiro) references enfermeiros (id_enfermeiro),
    foreign key (id_enfermeiro_2) references enfermeiros (id_enfermeiro)
);