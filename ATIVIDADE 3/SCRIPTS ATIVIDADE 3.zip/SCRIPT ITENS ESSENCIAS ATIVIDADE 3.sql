USE CLINICA_LOUREIRO;

ALTER TABLE especialidade
ADD cardiologia bit,
ADD ortopedia bit,
ADD oncologia bit,
ADD infectologia bit,
ADD oftalmologia bit,
ADD geriatria bit,
ADD obstetricia bit;

INSERT INTO especialidade (pediatria, clinica_geral, gastroenterologia, dermatologia, cardiologia, ortopedia, oncologia, infectologia, oftalmologia, geriatria, obstetricia)
VALUE
(b'1', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0'),
(b'0', b'1', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0'),
(b'0', b'0', b'1', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0'),
(b'0', b'0', b'0', b'1', b'0', b'0', b'0', b'0', b'0', b'0', b'0'),
(b'0', b'0', b'0', b'0', b'1', b'0', b'0', b'0', b'0', b'0', b'0'),
(b'0', b'0', b'0', b'0', b'0', b'1', b'0', b'0', b'0', b'0', b'0'),
(b'0', b'0', b'0', b'0', b'0', b'0', b'1', b'0', b'0', b'0', b'0'),
(b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'1', b'0', b'0', b'0'),
(b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'1', b'0', b'0'),
(b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'1', b'0'),
(b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'0', b'1');

INSERT INTO convenio (nome, cnpj)
VALUE
('Allianz Saúde', '04.439.627/0001-02'),
('Amil Saúde',' 29.309.127/0001-79'),
('Bradesco Saúde','92.693.118/0001'),
('Central Nacional Unimed','02.812.468/0005-30');

INSERT INTO tipos_quarto (apartamento, valor_apartamento, quarto_duplo, valor_quartoduplo, enfermaria, valor_enfermaria)
VALUE
(b'1','100',b'0','0',b'0','0');

INSERT INTO tipos_quarto (apartamento, valor_apartamento, quarto_duplo, valor_quartoduplo, enfermaria, valor_enfermaria)
VALUE
(b'0','0',b'1','200',b'0','0');

INSERT INTO tipos_quarto (apartamento, valor_apartamento, quarto_duplo, valor_quartoduplo, enfermaria, valor_enfermaria)
VALUE
(b'0','0',b'0','0',b'1','300');

INSERT INTO quarto (id_tipodequarto, numero_quarto)
VALUE 
('1', '01'),
('1', '02'),
('1', '03'),
('1', '04'),
('1', '05'),
('2', '06'),
('2', '07'),
('2', '08'),
('2', '09'),
('2', '10'),
('3', '11'),
('3', '12'),
('3', '13'),
('3', '14'),
('3', '15');