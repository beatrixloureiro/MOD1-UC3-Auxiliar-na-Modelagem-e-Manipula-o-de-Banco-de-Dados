USE CLINICA_LOUREIRO;

INSERT INTO medicos (id_especialidades, nome, crm, data_nascimento, endereco, telefone, email)  
VALUE 
('1', 'Lívia Débora Mariane Freitas',' 90.264/SP','1964/10/12', 'Rua Jerônimo Monteiro - 581 - Cariacica/ES', '(27) 3577-7472', 'liviadebora@gmail.com'),
('2','Clara Rita Almeida','25.965/SP','1988/07/24','Rodovia BR-158 - 783- Pato Branco/PR','(46) 2628-1624','clara.rita.almeida@guiamaritimo.com.br'),
('3','Joana Maria Rafaela Moura','45.125/SP','1964/07/07','Escadaria José Caetano da Silva 14 - Vitória/ES','(27) 3617-7741','joana_moura@macaubas.com'),
('4','Catarina Liz Elaine Aparício','78.852/SP','1989/05/02','Rua Frei Paulo - 293 - Aracaju/SE','(79) 2730-4723','catarinalizaparicio@konekoshouten.com.br'),
('5','Carlos Eduardo Filipe da Cruz','78.845/SP','1987/05/15','Rua P-02 - 993 - Uberlândia/MG','(34) 3502-3957','carlos_dacruz@estruturalbr.com.br'),
('6','Natália Juliana Isabela Corte Real','89.726/PE','1977/03/09','Avenida Bonifácio Sachetti - 562 - Rondonópoli/MT','(66) 3944-4000','natalia.juliana.cortereal@cognis.com'),
('7','Isabel Milena de Paula','36.582/RJ','1975/04/10','Rua Carlos Cagnalli - 258 - Rio Branco/RS','(54) 3966-9655','isabel_depaula@salvagninigroup.com'),
('8','Clarice Fernanda Rosângela Corte Real',' 45.164/PI','1982/11/02', 'Rua Gregório Ferreira Camargo - 641 - Birigüi/SP', '(18) 3568-8850', 'claricefernanda@gmail.com'),
('9','Lorena Olivia Renata Castro',' 54.445/SP','1965/09/04', 'Rua Raimundo Pessoa de Almeida - 458 - Boa Vista/RR', '(95) 2714-6697', 'lorenaoliveira@gmail.com'),
('10','Lucas Cláudio Raimundo Figueiredo',' 78.369/PE','1989/04/04', 'Rua Santa Celina - 183 - Parnamirim/RN', '16/02/1943', 'lucas.claudio.figueiredo@gsw.com.br');

INSERT INTO medicos_especialidade (id_medicos, id_especialidades)
VALUE
('1', '1'),
('2', '2'),
('3', '3'),
('4', '4'),
('5', '5'),
('6', '6'),
('7', '7'),
('8', '8'),
('9', '9'),
('10', '10');

INSERT INTO pacientes (id_convenio, tempo_carencia, nome, cpf, rg, data_nascimento, cep, telefone, email)
VALUE
('2', '02','Eduardo Guilherme Luís da Cunha','033.496.780-50','47.433.750-9','1962/08/12','61921-390','(85) 3512-5061','eduardo_guilherme_dacunha@corp.globo.com'),
('2', '02', 'Noah Elias Rezende','610.555.507-55','10.845.929-9','1949/09/05','98300-975','(55) 3508-5875','noaheliasrezende@hotmai.com.br'),
('3', '03', 'Juan César Renan Baptista','009.786.117-05','10.275.731-8','1981/10/02','72900-246','(61) 3613-0103','juan-baptista90@vitacard.com.br'),
(null, null, 'Márcio Mário Silva','450.511.940-87','41.386.482-0','2005/08/07','58301-325','(83) 3613-0104','marcio_silva@mpcnet.com'),
('4', '04', 'Débora Sophia Fabiana Cardoso','516.811.224-21','20.946.882-8','1995/01/09','07860-100','(11) 3504-6849','deborasophiacardoso@bom.com'),
('1', '01', 'Stefany Elaine Rebeca Freitas','304.249.628-70','30.580.175-2','1996/10/01','74354-678','(62) 2639-4170','stefany-freitas76@teofilorezende.com'),
(null, null, 'Adriana Yasmin Oliveira','268.150.430-96','49.134.481-8','2001/03/20','41220-760','(71) 2640-8710','adriana_oliveira@guiamaritimo.com'),
('1', '01', 'Tânia Heloise Andrea Vieira','242.204.006-30','44.219.899-1','1979/10/07','23097-235','(21) 2615-7048','tania.heloise.vieira@panevale.com'),
(null, null, 'Renata Aline Hadassa Souza','053.470.424-78','31.449.875-8','1998/05/03','29206-500','(27) 3722-2387','renata.aline.souza@tursi.com'),
(null, null, 'Manuel Kauê Ferreira', '179.363.389-42','47.480.763-0', '1964/10/11', '53370-315','(62) 3916-2334','manuel_kaue_ferreira@solarisbrasil.com.br');

INSERT INTO enfermeiros (nome, cre, data_nascimento)
VALUE 
('Ryan Osvaldo Moura', 'CRE/SP025698', '1964/07/06'),
('Bianca Luna Silva', 'CRE/PE254682', '1989/05/04'),
('Bruna Renata Barbosa','CRE/RR896547','1958/12/11'),
('Daniel Calebe Ian da Silva','CRE/AM674512','1988/07/25'),
('Brenda Adriana da Rosa','CRE/PE486972','1987/05/14'),
('Aurora Melissa Lúcia Assis','CRE/PE335489','1977/03/08'),
('Rosa Olivia Francisca Teixeira','CRE/SP894532','1975/04/09'),
('Renan Martin da Luz','CRE/RJ874523','1990/01/12'),
('Mateus Felipe Drumond','CRE/RJ289637','1992/08/25'),
('Esther Fernanda','CRE/SP452976','1969/04/25');

INSERT INTO receituario (instrucoes, medicamento_1, medicamento_2, medicamento_3, quant_medicamento_1, quant_medicamento_2, quant_medicamento_3, data_consulta)
VALUE
('Tomar 1(um) comprimido de Ciprofloxacino, por via oral, a cada 12 (doze) horas, por 7(sete dias). Tomar 1(um) comprimido de Carbenicilina, por via oral, a cada 04 (quatro) horas, por 7(sete dias).', 'Ciprofloxacino 500mg', 'Carbenicilina 200mg', null, '14','42', null, '2019/10/10'),
('Tomar 1(um) comprimido de Azasone, por via oral, a cada 08 (oito) horas, por 5(cinco dias). Tomar 1(um) comprimido de Demevate, por via oral, a cada 12 (doze) horas, por 7(sete dias).', 'Azasone 600mg', 'Demevate 300mg', null, '15','14', null, '2020/07/25'),
('Tomar 1(um) comprimido de Azasone, por via oral, a cada 08 (oito) horas, por 5(cinco dias). Tomar 1(um) comprimido de Demevate, por via oral, a cada 12 (doze) horas, por 7(sete dias).', 'Azasone 600mg', 'Demevate 300mg', null, '15','14', null, '2020/06/02');

INSERT INTO consultas (id_medicos, id_pacientes, id_receituario, id_conveni, id_medicos_especialidade, valor, data_realizada)
VALUE
('1','3','1','3','1', null,'2019/10/10'),
('2','4', null, null,'2', '300','2019/11/25'),
('4','6', null,'1','4', null,'2020/02/15'),
('1','9','3', null,'1', '300','2020/06/02'),
('2','1','2','2','2', null,'2020/07/25'),
('3','5', null, '4','3', null,'2020/09/07'),
('4','2', null,'2','4', null,'2021/03/04'),
('1','7', null, null,'1', 500,'2021/08/18'),
('2','8', null, '1','2', null ,'2021/09/27'),
('5','10',null, null,'5', 400,'2021/11/03');

INSERT INTO internacao (id_quarto, data_entrada, data_prevista, data_saida, procedimentos)
VALUE 
('1', '2020/07/25', '2020/07/27', '2020/07/27', null),
('2', '2021/03/04', '2021/03/07', '2021/03/07', null),
('3', '2019/10/10', '2019/10/13', '2019/10/13', null),
('7', '2019/11/25', '2019/11/27', '2019/11/27', null),
('8', '2020/09/07', '2020/09/10', '2020/09/10', null),
('11', '2020/06/02', '2020/06/05', '2020/06/05', null),
('12', '2021/08/18', '2020/08/20', '2020/08/20', null);

INSERT INTO internacao_paciente_medico (id_internacao, id_medicos, id_pacientes, id_enfermeiro, id_enfermeiro_2)
VALUE 
('1','2','1','1','2'),
('2','4','2','3','4'),
('3','1','3','5','6'),
('4','2','4','7','8'),
('5','3','5','9', null),
('6','4','6','10',null),
('7','1','7','10',null);