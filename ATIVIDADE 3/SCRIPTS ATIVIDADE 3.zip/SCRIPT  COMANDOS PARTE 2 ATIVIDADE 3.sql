USE CLINICA_LOUREIRO;

ALTER TABLE medicos
ADD COLUMN atividade bit;

UPDATE medicos
SET atividade = b'1'
WHERE id_medicos = '1';

UPDATE medicos
SET atividade = b'1'
WHERE id_medicos = '2';

UPDATE medicos
SET atividade = b'1'
WHERE id_medicos = '3';

UPDATE medicos
SET atividade = b'1'
WHERE id_medicos = '4';

UPDATE medicos
SET atividade = b'1'
WHERE id_medicos = '5';

UPDATE medicos
SET atividade = b'1'
WHERE id_medicos = '6';

UPDATE medicos
SET atividade = b'1'
WHERE id_medicos = '7';

UPDATE medicos
SET atividade = b'0'
WHERE id_medicos = '8';

UPDATE medicos
SET atividade = b'0'
WHERE id_medicos = '9';

UPDATE medicos
SET atividade = b'0'
WHERE id_medicos = '10';

UPDATE internacao 
SET data_saida = adddate(data_saida , INTERVAL 3 DAY)
WHERE id_quarto = 11;

UPDATE internacao 
SET data_saida = adddate(data_saida , INTERVAL 3 DAY)
WHERE id_quarto = 12;

DELETE FROM convenio
WHERE id_convenio = 4;

UPDATE consultas
SET id_conveni = "null"
WHERE id_conveni = 4;